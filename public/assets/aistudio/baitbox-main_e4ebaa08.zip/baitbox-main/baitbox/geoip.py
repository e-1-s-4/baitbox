"""Server-side GeoIP resolution with in-memory caching and threat scoring."""

from __future__ import annotations

import asyncio
import ipaddress
import logging
import threading
import time
import urllib.request
import json
from typing import Any

from . import __version__
from .config import settings

logger = logging.getLogger("baitbox.geoip")

# In-memory cache: ip -> {data, expires}
_CACHE: dict[str, dict[str, Any]] = {}
_TTL = 3600  # 1 hour

# Bound the cache so scanners rotating across huge IP ranges cannot grow
# memory without limit. Expired entries are evicted first, then oldest.
_CACHE_MAX_ENTRIES = 4096

# Bound outbound lookups so a burst of events from many new IPs cannot swamp
# the free ip-api.com quota (45 req/min) or spawn an unbounded number of
# worker threads.
_MAX_INFLIGHT_LOOKUPS = 8
_REMOTE_MIN_INTERVAL = 1.5  # seconds between outbound requests
_inflight: set[str] = set()
_inflight_lock = threading.Lock()
_last_remote_at = 0.0
_remote_lock = threading.Lock()

# Known Tor exit node ranges / suspicious ASN keywords (heuristic)
_SUSPICIOUS_ASN_KEYWORDS = {
    "digitalocean", "linode", "vultr", "ovh", "hetzner", "leaseweb",
    "serverius", "choopa", "frantech", "aeza", "m247", "zenlayer",
    "serverstack", "datacamp", "host europe", "datawagon", "combahton",
}


def _cache_put(ip: str, data: dict[str, Any], expires: float) -> None:
    """Store a cache entry, evicting expired/oldest entries when over capacity."""
    if len(_CACHE) >= _CACHE_MAX_ENTRIES and ip not in _CACHE:
        now = time.time()
        expired = [k for k, v in _CACHE.items() if v["expires"] <= now]
        for k in expired:
            del _CACHE[k]
        if len(_CACHE) >= _CACHE_MAX_ENTRIES:
            oldest = sorted(_CACHE.items(), key=lambda kv: kv[1]["expires"])[: len(_CACHE) // 4]
            for k, _ in oldest:
                del _CACHE[k]
    _CACHE[ip] = {"data": data, "expires": expires}


def cache_geo(ip: str, data: dict[str, Any], ttl: int = _TTL) -> None:
    """Prime the in-memory GeoIP cache (used by demo seeding and simulation)."""
    _cache_put(ip, dict(data), time.time() + ttl)


def _is_private(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
        return addr.is_private or addr.is_loopback or addr.is_link_local
    except ValueError:
        return False


def _threat_score(data: dict[str, Any]) -> int:
    """Heuristic 0-100 threat score based on GeoIP data."""
    score = 0
    if not data:
        return score
    # VPN/Hosting ASN
    asn_name = (data.get("isp") or data.get("org") or "").lower()
    if any(kw in asn_name for kw in _SUSPICIOUS_ASN_KEYWORDS):
        score += 40
    # Non-US/EU hosting countries with high bot traffic
    high_risk_countries = {"CN", "RU", "BR", "IN", "KP", "IR", "VN", "UA"}
    if data.get("countryCode") in high_risk_countries:
        score += 30
    # Proxy/VPN flag
    if data.get("proxy") or data.get("hosting"):
        score += 30
    return min(score, 100)


async def lookup_ip(ip: str) -> dict[str, Any]:
    """Return GeoIP info dict for an IP. Uses memory and SQLite caches to avoid rate-limiting."""
    if not settings.geoip_enabled:
        return _unknown_geoip(ip, reason="disabled")

    if _is_private(ip):
        return {
            "ip": ip,
            "city": "Local Host",
            "country": "Private Network",
            "countryCode": "XX",
            "lat": 37.7749,
            "lon": -122.4194,
            "isp": "Loopback",
            "org": "Private",
            "threat_score": 0,
        }

    now = time.time()
    cached = _CACHE.get(ip)
    if cached and cached["expires"] > now:
        return cached["data"]

    try:
        from .db import get_geoip_cache
        cached_data = await get_geoip_cache(ip)
        if cached_data:
            _cache_put(ip, cached_data, now + _TTL)
            return cached_data
    except Exception as exc:
        logger.debug("GeoIP SQLite cache read failed for %s: %s", ip, exc)

    data: dict[str, Any] = _unknown_geoip(ip)

    with _inflight_lock:
        if len(_inflight) >= _MAX_INFLIGHT_LOOKUPS:
            data["reason"] = "busy"
            _cache_put(ip, data, now + 60)
            return data
        _inflight.add(ip)
    try:
        data = await _lookup_remote(ip, data)
    except Exception as exc:
        logger.debug("GeoIP lookup failed for %s: %s", ip, exc)
    finally:
        with _inflight_lock:
            _inflight.discard(ip)

    # Only cache successful answers for the full TTL. Failures/throttling get
    # a short negative cache so a transient outage is retried soon.
    if data.get("reason"):
        _cache_put(ip, data, now + 60)
        return data

    _cache_put(ip, data, now + _TTL)
    try:
        from .db import set_geoip_cache
        await set_geoip_cache(ip, data, ttl=_TTL)
    except Exception as exc:
        logger.debug("GeoIP SQLite cache write failed for %s: %s", ip, exc)
    return data


async def _lookup_remote(ip: str, fallback: dict[str, Any]) -> dict[str, Any]:
    """Query ip-api.com without blocking the event loop (runs in a thread)."""
    global _last_remote_at
    now = time.time()
    with _remote_lock:
        if now - _last_remote_at < _REMOTE_MIN_INTERVAL:
            throttled = dict(fallback)
            throttled["reason"] = "throttled"
            return throttled
        _last_remote_at = now

    # ip-api.com free tier: 45 req/min, no API key needed
    url = f"http://ip-api.com/json/{ip}?fields=status,country,countryCode,city,lat,lon,isp,org,proxy,hosting"

    def _fetch() -> dict[str, Any] | None:
        req = urllib.request.Request(url, headers={"User-Agent": f"BaitBox/{__version__}"})
        with urllib.request.urlopen(req, timeout=4) as resp:
            return json.loads(resp.read().decode())

    try:
        raw = await asyncio.to_thread(_fetch)
    except Exception:
        return fallback

    if not isinstance(raw, dict) or raw.get("status") != "success":
        return fallback

    data = dict(fallback)
    data.update({
        "city": raw.get("city", "Unknown"),
        "country": raw.get("country", "Unknown"),
        "countryCode": raw.get("countryCode", "XX"),
        "lat": raw.get("lat", 0.0),
        "lon": raw.get("lon", 0.0),
        "isp": raw.get("isp", "Unknown"),
        "org": raw.get("org", "Unknown"),
        "threat_score": _threat_score(raw),
    })
    data.pop("reason", None)
    return data


def _unknown_geoip(ip: str, reason: str = "unknown") -> dict[str, Any]:
    """Return a stable placeholder shape for unavailable GeoIP data."""
    return {
        "ip": ip,
        "city": "Unknown",
        "country": "Unknown",
        "countryCode": "XX",
        "lat": 0.0,
        "lon": 0.0,
        "isp": "Unknown",
        "org": "Unknown",
        "threat_score": 0,
        "reason": reason,
    }


def get_cached(ip: str) -> dict[str, Any] | None:
    """Return cached GeoIP data without performing a fresh lookup."""
    entry = _CACHE.get(ip)
    if entry and entry["expires"] > time.time():
        return entry["data"]
    return None


def schedule_lookup(ip: str) -> None:
    """Queue a background GeoIP lookup when data is not already cached."""
    if not settings.geoip_enabled or _is_private(ip) or get_cached(ip) is not None:
        return

    from .async_bridge import fire_and_forget

    fire_and_forget(lookup_ip(ip))
